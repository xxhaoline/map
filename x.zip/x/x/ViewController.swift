//
//  ViewController.swift
//  x
//
//  Created by Агеева ИСИП 20 on 28.03.2022.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    //Переменные для создания маршрута
    var itemMapFirst: MKMapItem!
    var itemMapSecond: MKMapItem!
    
    
    
    //для работы с картой создается manager
    let manager: CLLocationManager = {
        let locationManager = CLLocationManager() //получение местоположение
        locationManager.activityType = .fitness //точно определяет местоположение
        locationManager.desiredAccuracy = kCLLocationAccuracyBest //
        locationManager.distanceFilter = 1 //фильтр дистанции
        locationManager.showsBackgroundLocationIndicator = true //отобразить индикатор на карте
        locationManager.pausesLocationUpdatesAutomatically = true //отображение обновления
        return locationManager
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        manager.delegate = self
        authorization()
        
    }
    
    func locationManager( manager: CLLocationManager, didUpdateHeading location: [CLLocation]) {
        //отображение координат с помощью цикла
        for location in location {
            print(location.coordinate.latitude)
            print(location.coordinate.longitude)
            itemMapFirst = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
        }
    }
    //функции фаторизации
    func authorization() {
        //Проверка на разрешение использования местоположения (ALWAYS - всегда, INUSE - когда приложения открыто)
        if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            mapView.showsUserLocation = true //отобразить на карте текущее местоположение пользователя
        } else {
            manager.requestWhenInUseAuthorization()
        }
    }

}

